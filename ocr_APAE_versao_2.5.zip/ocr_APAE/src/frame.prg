Function main()

* ocr_APAE versao 2.5 - 06/10/2026

set century on
set date to british

public cDBF_file := "c:\ocr_apae\dbf\frame.dbf"
aStruct := { { "row","C",80,0 }, ;
			 { "obs","C",5,0 }}
			 dbcreate (( cDBF_file ),aStruct )
use "c:\ocr_apae\dbf\frame.dbf"
append from "c:\ocr_apae\temp\#861010799_apae_select.txt" DELIMITED
close

public cDBF_file2 := "c:\ocr_apae\dbf\data.dbf"
aStruct := { { "n_SFPN_ref","C",6,0 }, ;
			{ "NamePac","C",80,0 }, ;
			{ "MunRes","C",80,0 }, ;
			{ "DtNasc","D",10,0 }, ;
			{ "Age","C",3,0 }, ;
			{ "obs","C",5,0 }}
			 dbcreate (( cDBF_file2 ),aStruct )

public nPos_SFPN, cName, cMunicRes, cDtNasc, cAge

use "c:\ocr_apae\dbf\frame.dbf"
locate for at( "SFPN", row) > 1

if found() = .T. 
? recno()
nPos_SFPN := recno()
? nPos_SFPN
goto nPos_SFPN + 2
cName := alltrim( row )
? cName
skip
cMunicRes := alltrim( row )
? cMunicRes
skip +2
cDtNasc := left( alltrim( row ), 10)
? cDtNasc
skip
cAge := alltrim( row )
? cAge
close

use "c:\ocr_apae\dbf\data.dbf"
append blank
replace n_SFPN_ref with alltrim( str( nPos_SFPN ))
replace NamePac with alltrim( cName )
replace MunRes with alltrim( cMunicRes )
replace DtNasc with ctod( cDtNasc )
replace Age with alltrim( cAge )
close

endif

return
