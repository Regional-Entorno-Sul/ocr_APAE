Function main()

* OCR_apae versao 2.4
* --create: Cria um arquivo DBF com linhas especificas do arquivo "apae_sif_fase21.txt".
* --pass: Passa para o processamento batch as linhas inicial e final para recortar.

public cMode := alltrim(HB_Argv( 1 ))

if cMode = "--create_dbf"
create_dbf()
endif

if cMode = "--pass"
pass()
endif

function create_dbf
public cDBF_file := "c:\ocr_apae\dbf\lines.dbf"
aStruct := { { "lines","C",5,0 }, ;
			 { "obs","C",10,0 }}
			 dbcreate (( cDBF_file ),aStruct )
use "c:\ocr_apae\dbf\lines.dbf"
append from "c:\ocr_apae\temp\lines2.txt" DELIMITED
close
copy file "c:\ocr_apae\dbf\lines.dbf" to "c:\ocr_apae\temp\static_lines.dbf"

return

function pass

do while .T.

use "c:\ocr_apae\dbf\lines.dbf"
copy next 1 to "c:\ocr_apae\temp\lines_x.txt" SDF
close

use "c:\ocr_apae\dbf\lines.dbf"
delete record 1
pack
copy next 1 to "c:\ocr_apae\temp\lines_y.txt" SDF
close

use "c:\ocr_apae\dbf\lines.dbf"
cReferenceString := lines -> ( fieldget(1))
close
if empty( cReferenceString ) = .T.
exit
endif

hb_run("c:\ocr_apae\bat\run_apae.bat --separate")

enddo

return

return