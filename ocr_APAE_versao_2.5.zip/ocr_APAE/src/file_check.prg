Function main()

* OCR_apae versao 1.8
* Checa os arquivos dentro do diretorio "original_PDF" e renomeia o arquivo em caso de conformidade.

cMode := alltrim(HB_Argv( 1 ))

if cMode = "--empty_dir"
empty_dir()
endif

if cMode = "--pdf_quant"
pdf_quant()
endif

if cMode = "--rename"
rename()
endif

if cMode = "--check_rename"
check_rename()
endif

function empty_dir
lFile := file("c:\ocr_apae\original_PDF\*.*")
if lFile = .F.
errorlevel(1120)
endif
return

function pdf_quant
public nQuant := 0
aDir := Directory("c:\ocr_apae\original_PDF\*.pdf", "HSD")
nQuant := len(aDir)
if nQuant > 1
errorlevel(1121)
endif
return

function rename
public aDir2 := Directory("c:\ocr_apae\original_PDF\*.pdf", "HSD")
public cOldFile := "c:\ocr_apae\original_PDF\" + alltrim(aDir2[ 1,1 ])
public cNewFile := "c:\ocr_apae\original_PDF\sifilis.pdf"
rename (cOldFile) to (cNewFile)
return

function check_rename
if file("c:\ocr_apae\original_PDF\sifilis.pdf") = .F.
errorlevel(1122)
endif
return

return