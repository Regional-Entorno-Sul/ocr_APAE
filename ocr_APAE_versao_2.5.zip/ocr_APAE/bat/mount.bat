cls
@echo off
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"
c:\ocr_apae\bin\cecho.exe white blue "* mount.bat 21/09/2026                                                                *"
c:\ocr_apae\bin\cecho.exe white blue "* Script para montagem do executavel principal do ocr_APAE                            *"
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"

c:\ocr_apae\bin\cecho.exe green black "Transferindo os arquivos prg para o diretorio do compilador..."
cd\
cd ocr_APAE
cd src
copy *.prg c:\hb30\bin\*.prg

c:\ocr_apae\bin\cecho.exe green black "Compilando os arquivos prg..."

cd\
cd hb30/bin
hbmk2 file_check.prg
hbmk2 lines.prg

c:\ocr_apae\bin\cecho.exe green black "Transferindo os arquivos compilados para o diretorio ocr_APAE..."
copy file_check.exe c:\ocr_APAE\bin\file_check.exe
copy lines.exe c:\ocr_APAE\bin\lines.exe

pause

c:\ocr_apae\bin\cecho.exe green black "Rodando o executavel principal do ocr_APAE..."
cd\
cd ocr_APAE/bat
run_apae.bat --transformer
