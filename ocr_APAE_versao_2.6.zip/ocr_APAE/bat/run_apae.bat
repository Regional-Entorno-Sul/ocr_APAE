cls
@echo off
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"
c:\ocr_apae\bin\cecho.exe white blue "* ocr_APAE versao 2.6 - 19/11/2026                                                    *"
c:\ocr_apae\bin\cecho.exe white blue "* Utilitario para conversao de documento com sorologia da APAE para arquivo de texto. *"
c:\ocr_apae\bin\cecho.exe white blue "* https://github.com/Regional-Entorno-Sul/ocr_APAE                                    *"
c:\ocr_apae\bin\cecho.exe white blue "* Sintaxe: run_apae.bat --[opcao]                                                     *"
c:\ocr_apae\bin\cecho.exe white blue "* --transformer, --separate, --transfer                                               *"
c:\ocr_apae\bin\cecho.exe white blue "* Exemplo: run_apae.bat --separate                                                    *"
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"

if %1 equ --transformer (
c:\ocr_apae\bin\cecho.exe green black "Iniciando a opcao --transformer."
call :transformer
goto :eof
)

if %1 equ --separate (
c:\ocr_apae\bin\cecho.exe green black "Iniciando a opcao --separate."
call :separate
goto :eof
)

if %1 neq --transformer (
c:\ocr_apae\bin\cecho.exe red black "Erro! Uso de argumento na linha de comando e obrigatorio."
goto :eof
)

if %1 neq --separate (
c:\ocr_apae\bin\cecho.exe red black "Erro! Uso de argumento na linha de comando e obrigatorio."
goto :eof
)
exit /b

:transformer

c:\ocr_apae\bin\cecho.exe green black "Criando um arquivo de log..."
echo "Arquivo de log ocr_APAE" > c:\ocr_APAE\log\log_file.txt
echo [%date% %time%] - Iniciando o arquivo de log. >> c:\ocr_APAE\log\log_file.txt

c:\ocr_apae\bin\file_check.exe --empty_dir

if %ERRORLEVEL% neq 0 (
c:\ocr_apae\bin\cecho.exe red black "Erro! Diretorio 'original_PDF' esta vazio."
exit /b
)

c:\ocr_apae\bin\file_check.exe --pdf_quant

if %ERRORLEVEL% neq 0 (
c:\ocr_apae\bin\cecho.exe red black "Erro! Diretorio 'original_PDF' contem mais de um arquivo."
exit /b
)

c:\ocr_apae\bin\file_check.exe --rename

c:\ocr_apae\bin\file_check.exe --check_rename

if %ERRORLEVEL% neq 0 (
c:\ocr_apae\bin\cecho.exe red black "Erro! Renomear o arquivo PDF na pasta 'original_PDF' falhou."
exit /b
)

c:\ocr_apae\bin\cecho.exe green black "Limpando diretorios com arquivos remanecentes."
cd\
cd ocr_apae
cd ocr_pdf
del /q *.pdf
cd\
cd ocr_apae
cd temp
del /q *.txt
del /q *.dbf
cd\
cd ocr_apae
cd dbf
del /q *.dbf
cd\
cd ocr_apae
cd log
del /q *.log

c:\ocr_apae\bin\cecho.exe green black "Usando o NAPS2 para conversao para PDF editavel."
c:\ocr_apae\bin\cecho.exe white black "Aguarde..."

c:\ocr_apae\app\naps2.console.exe -i "c:\ocr_apae\original_PDF\sifilis.pdf" -o "c:\ocr_apae\ocr_pdf\ocr_pdf.pdf" -n 0 --enableocr --ocrlang eng+por

c:\ocr_apae\bin\cecho green black "Usando XPDF para converter o PDF em arquivo de texto."

c:\ocr_apae\bin\pdftotext.exe -raw "c:\ocr_apae\ocr_pdf\ocr_pdf.pdf" "c:\ocr_apae\temp\apae_sifilis.txt"

c:\ocr_apae\bin\cecho green black "Usando o iconv for Windows para realizar a transliteracao do texto."

c:\ocr_apae\bin\iconv -f WINDOWS-1252 -t ASCII//TRANSLIT c:\ocr_apae\temp\apae_sifilis.txt > c:\ocr_apae\temp\apae_sif_fase2.txt

c:\ocr_apae\bin\cecho.exe green black "Usando o gawk for Windows para remover acentuacao aguda do texto."

c:\ocr_apae\bin\gawk-3.1.6.exe "{gsub(/'/, \"\");print}" c:\ocr_APAE\temp\apae_sif_fase2.txt > c:\ocr_APAE\temp\apae_sif_fase3.txt

c:\ocr_apae\bin\cecho.exe green black "Usando o sed for Windows para remover outros acentos."

c:\ocr_apae\bin2\sed "s/\^//g" c:\ocr_APAE\temp\apae_sif_fase3.txt > c:\ocr_APAE\temp\apae_sif_fase4.txt
c:\ocr_apae\bin2\sed "s/\~//g" c:\ocr_APAE\temp\apae_sif_fase4.txt > c:\ocr_APAE\temp\apae_sif_fase5.txt

c:\ocr_apae\bin\cecho.exe green black "Usando o sed for Windows para remover linhas em branco no texto."
c:\ocr_apae\bin2\sed "/^$/d" c:\ocr_APAE\temp\apae_sif_fase5.txt > c:\ocr_APAE\temp\apae_sif_fase6.txt"

c:\ocr_apae\bin\cecho.exe green black "Usando o sed for Windows para remover determinadas linhas do texto."
c:\ocr_apae\bin2\sed "/INSTITUTO DE/d" c:\ocr_APAE\temp\apae_sif_fase6.txt > c:\ocr_APAE\temp\apae_sif_fase7.txt
c:\ocr_apae\bin2\sed "/DO ESTADO DE GOIAS/d" c:\ocr_APAE\temp\apae_sif_fase7.txt > c:\ocr_APAE\temp\apae_sif_fase8.txt
c:\ocr_apae\bin2\sed "/Gestantes Alteradas/d" c:\ocr_APAE\temp\apae_sif_fase8.txt > c:\ocr_APAE\temp\apae_sif_fase9.txt
c:\ocr_apae\bin2\sed "/Mes Ref.:/d" c:\ocr_APAE\temp\apae_sif_fase9.txt > c:\ocr_APAE\temp\apae_sif_fase10.txt
c:\ocr_apae\bin2\sed "/Nome da Gestante/d" c:\ocr_APAE\temp\apae_sif_fase10.txt > c:\ocr_APAE\temp\apae_sif_fase11.txt
c:\ocr_apae\bin2\sed "/Endereco Completo/d" c:\ocr_APAE\temp\apae_sif_fase11.txt > c:\ocr_APAE\temp\apae_sif_fase12.txt
c:\ocr_apae\bin2\sed "/Nome do Posto de Coleta/d" c:\ocr_APAE\temp\apae_sif_fase12.txt > c:\ocr_APAE\temp\apae_sif_fase13.txt
c:\ocr_apae\bin2\sed "/Exame Papel Filtro/d" c:\ocr_APAE\temp\apae_sif_fase13.txt > c:\ocr_APAE\temp\apae_sif_fase14.txt
c:\ocr_apae\bin2\sed "/Pag.:/d" c:\ocr_APAE\temp\apae_sif_fase14.txt > c:\ocr_APAE\temp\apae_sif_fase15.txt
c:\ocr_apae\bin2\sed "/Posto de Coleta/d" c:\ocr_APAE\temp\apae_sif_fase15.txt > c:\ocr_APAE\temp\apae_sif_fase16.txt

c:\ocr_apae\bin2\sed "/Dt. Ult. Menstr./d" c:\ocr_APAE\temp\apae_sif_fase16.txt > c:\ocr_APAE\temp\apae_sif_fase17.txt
c:\ocr_apae\bin2\sed "/Dt. Nasc./d" c:\ocr_APAE\temp\apae_sif_fase17.txt > c:\ocr_APAE\temp\apae_sif_fase18.txt
c:\ocr_apae\bin2\sed "/Fone: (62) 3238-7000/d" c:\ocr_APAE\temp\apae_sif_fase18.txt > c:\ocr_APAE\temp\apae_sif_fase19.txt
c:\ocr_apae\bin2\sed "/Data Coleta PF/d" c:\ocr_APAE\temp\apae_sif_fase19.txt > c:\ocr_APAE\temp\apae_sif_fase20.txt

c:\ocr_apae\bin\cecho.exe green black "Inclui na primeira linha do texto a string 'Resultados:'"
c:\ocr_apae\bin2\sed "1i\Resultados:" c:\ocr_APAE\temp\apae_sif_fase20.txt > c:\ocr_APAE\temp\apae_sif_fase21.txt

c:\ocr_apae\bin\cecho.exe green black "Cria um arquivo de texto que lista as linhas que contem a palavra 'Resultados:'"
c:\ocr_apae\bin\gawk-3.1.6.exe "/Resultados:/ {print NR}" c:\ocr_APAE\temp\apae_sif_fase21.txt > c:\ocr_APAE\temp\lines.txt

rem c:\ocr_apae\bin\cecho.exe green black "Exclui a ultima linha do arquivo 'lines.txt'"
rem c:\ocr_apae\bin2\sed "$d" c:\ocr_APAE\temp\lines.txt > c:\ocr_APAE\temp\lines2.txt
copy c:\ocr_APAE\temp\lines.txt c:\ocr_APAE\temp\lines2.txt

call :transfer

copy "c:\ocr_APAE\temp\#*.txt" "c:\ocr_APAE\out\"

c:\ocr_apae\bin\rename_file.exe

c:\ocr_apae\bin\cecho.exe red black "Fim do processamento."

goto :eof

:transfer

c:\ocr_apae\bin\cecho.exe green black "Gera arquivo DBF com linhas especificas do arquivo 'apae_sif_fase21.txt'."
c:\ocr_apae\bin\lines.exe --create_dbf
c:\ocr_apae\bin\cecho.exe green black "Passa dados para os arquivos 'lines_x' e 'lines_y'."
c:\ocr_apae\bin\lines.exe --pass

goto :eof

:separate

c:\ocr_apae\bin\cecho.exe green black "Passa os dados dos arquivos 'lines_x' e 'lines_y' para variaveis do batch."
set /p linha_x=<c:\ocr_APAE\temp\lines_x.txt
set /p linha_y=<c:\ocr_APAE\temp\lines_y.txt
set file_name=#%random%%random%

REM echo ------------------------------------------------------------------------------ >> c:\ocr_APAE\log\log_file.txt
REM echo Linha x, linha y, nome do arquivo txt >> c:\ocr_APAE\log\log_file.txt
REM echo ------------------------------------------------------------------------------ >> c:\ocr_APAE\log\log_file.txt
REM echo [%date% %time%] - %linha_x% , %linha_y% , %file_name%_apae_select.txt >> c:\ocr_APAE\log\log_file.txt

c:\ocr_apae\bin\cecho.exe white black "----------------------------------------------------------------"
c:\ocr_apae\bin\cecho.exe white black "Linha x, linha y, nome do arquivo txt"
c:\ocr_apae\bin\cecho.exe white black "----------------------------------------------------------------"
c:\ocr_apae\bin\cecho.exe white black "[%date% %time%] - %linha_x% , %linha_y% , %file_name%_apae_select.txt"
c:\ocr_apae\bin\cecho.exe white black "----------------------------------------------------------------"

REM echo ------------------------------------------------------------------------------
REM echo Linha x, linha y, nome do arquivo txt
REM echo ------------------------------------------------------------------------------
REM echo [%date% %time%] - %linha_x% , %linha_y% , %file_name%_apae_select.txt

REM @echo off

c:\ocr_apae\bin\cecho.exe green black "Seleciona os dados do paciente especificado no arquivo 'lines2.txt'."
timeout /t 1 /nobreak
c:\ocr_apae\bin2\sed -n "%linha_x%,%linha_y%p" c:\ocr_APAE\temp\apae_sif_fase21.txt > c:\ocr_APAE\temp\%file_name%_apae_select.txt

rem c:\ocr_apae\bin\cecho.exe green black "Gera arquivo de texto com o nome dos pacientes."
rem c:\ocr_apae\bin\gawk-3.1.6.exe "/SFPN/" c:\ocr_APAE\temp\apae_sif_fase21.txt > c:\ocr_APAE\temp\output_pacientes.txt

cd\
cd ocr_apae
cd bat

goto :eof

