cls
@echo off
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"
c:\ocr_apae\bin\cecho.exe white blue "* mount.bat 19/11/2026                                                                *"
c:\ocr_apae\bin\cecho.exe white blue "* Script para montagem do executavel principal do ocr_APAE                            *"
c:\ocr_apae\bin\cecho.exe white blue "***************************************************************************************"

c:\ocr_apae\bin\cecho.exe green black "Transferindo os arquivos prg para o diretorio do compilador..."
cd\
cd ocr_APAE
cd src
copy *.prg c:\hb32\bin\*.prg

c:\ocr_apae\bin\cecho.exe green black "Compilando os arquivos prg..."

cd\
cd hb32/bin
hbmk2 file_check.prg
hbmk2 lines.prg
hbmk2 rename_file.prg

c:\ocr_apae\bin\cecho.exe green black "Transferindo os arquivos compilados para o diretorio ocr_APAE..."
copy file_check.exe c:\ocr_APAE\bin\file_check.exe
copy lines.exe c:\ocr_APAE\bin\lines.exe
copy rename_file.exe c:\ocr_APAE\bin\rename_file.exe

c:\ocr_apae\bin\cecho.exe green black "Deseja rodar o executavel principal do ocr_APAE apos a montagem?..."

choice /c SN /m "Pressione S para Sim ou N para Nao"

if errorlevel 2 goto cancel
if errorlevel 1 goto continue

:continue
cd\
cd ocr_APAE/bat
run_apae.bat --transformer
goto fim

:cancel

:fim
pause

