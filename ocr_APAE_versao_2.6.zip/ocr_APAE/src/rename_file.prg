Function main()

* rename_file.prg
* Renomeia os arquivos com #, incluindo o nome do municipio no arquivo txt.

aStruct := { { "comp_name","C",70,0 }, ;
             { "simp_name","C",70,0 }}
			 dbcreate ("c:\ocr_apae\set\munics.dbf", aStruct)

use "c:\ocr_apae\set\munics.dbf"
append from "c:\ocr_apae\set\munics.txt" delimited with '"'
close

	  public aArray_mun_list := {}
	  use "c:\ocr_apae\set\munics.dbf"
      nRecs := reccount()
      FOR x := 1 TO nRecs
	  AAdd( aArray_mun_list, {alltrim(comp_name)} )
	  skip
	  NEXT
	  close

return